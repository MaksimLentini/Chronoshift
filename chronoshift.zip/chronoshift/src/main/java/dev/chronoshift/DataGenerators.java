package dev.chronoshift;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.data.recipes.ShapedRecipeBuilder;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.data.event.GatherDataEvent;

@EventBusSubscriber(modid = Chronoshift.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class DataGenerators {
    private DataGenerators() {
    }

    @SubscribeEvent
    public static void gather(GatherDataEvent event) {
        event.getGenerator().addProvider(
                event.includeServer(),
                new Recipes(event.getGenerator().getPackOutput(), event.getLookupProvider()));
    }

    private static final class Recipes extends RecipeProvider {
        Recipes(PackOutput output, CompletableFuture<HolderLookup.Provider> lookup) {
            super(output, lookup);
        }

        @Override
        protected void buildRecipes(RecipeOutput output) {
            ShapedRecipeBuilder.shaped(RecipeCategory.MISC, Chronoshift.TIME_STOP_WATCH.get())
                    .pattern("CNC")
                    .pattern("O O")
                    .define('C', Chronoshift.TIME_CRYSTAL.get())
                    .define('N', Items.NETHER_STAR)
                    .define('O', Items.CRYING_OBSIDIAN)
                    .unlockedBy("has_time_crystal", has(Chronoshift.TIME_CRYSTAL.get()))
                    .save(output);
        }
    }
}
