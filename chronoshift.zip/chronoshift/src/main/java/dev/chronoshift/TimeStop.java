package dev.chronoshift;

import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.GameRules;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = Chronoshift.MOD_ID)
public final class TimeStop {
    private static int remaining;
    private static UUID owner;
    private static int savedRandomTick;
    private static boolean savedFireTick;
    private static boolean savedDaylight;
    private static boolean savedWeather;
    private static boolean savedMobSpawning;

    private TimeStop() {
    }

    public static boolean isActive() {
        return remaining > 0;
    }

    public static void start(MinecraftServer server, UUID activator, int ticks) {
        if (isActive() || ticks <= 0) {
            return;
        }
        GameRules rules = server.getGameRules();
        savedRandomTick = rules.getInt(GameRules.RULE_RANDOMTICKING);
        savedFireTick = rules.getBoolean(GameRules.RULE_DOFIRETICK);
        savedDaylight = rules.getBoolean(GameRules.RULE_DAYLIGHT);
        savedWeather = rules.getBoolean(GameRules.RULE_WEATHER_CYCLE);
        savedMobSpawning = rules.getBoolean(GameRules.RULE_DOMOBSPAWNING);
        rules.getRule(GameRules.RULE_RANDOMTICKING).set(0, server);
        rules.getRule(GameRules.RULE_DOFIRETICK).set(false, server);
        rules.getRule(GameRules.RULE_DAYLIGHT).set(false, server);
        rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false, server);
        rules.getRule(GameRules.RULE_DOMOBSPAWNING).set(false, server);
        owner = activator;
        remaining = ticks;
    }

    private static void stop(MinecraftServer server) {
        GameRules rules = server.getGameRules();
        rules.getRule(GameRules.RULE_RANDOMTICKING).set(savedRandomTick, server);
        rules.getRule(GameRules.RULE_DOFIRETICK).set(savedFireTick, server);
        rules.getRule(GameRules.RULE_DAYLIGHT).set(savedDaylight, server);
        rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(savedWeather, server);
        rules.getRule(GameRules.RULE_DOMOBSPAWNING).set(savedMobSpawning, server);
        owner = null;
        remaining = 0;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (remaining > 0 && --remaining == 0) {
            stop(event.getServer());
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Pre event) {
        if (remaining > 0
                && !event.getEntity().level().isClientSide
                && !event.getEntity().getUUID().equals(owner)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        if (isActive()) {
            stop(event.getServer());
        }
    }
}
