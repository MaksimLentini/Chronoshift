package dev.chronoshift;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.Vec3;

public final class TimePocket {
    public static final ResourceKey<Level> KEY =
            ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath(Chronoshift.MOD_ID, "time_pocket"));

    private TimePocket() {
    }

    public static boolean enter(Entity entity) {
        return enter(entity, 0.5D, 0.5D);
    }

    public static boolean enter(Entity entity, double x, double z) {
        if (!(entity.level() instanceof ServerLevel from)) {
            return false;
        }
        ServerLevel target = from.getServer().getLevel(KEY);
        if (target == null) {
            return false;
        }
        Vec3 pos = new Vec3(x, target.getMinBuildHeight() + 4, z);
        return teleport(entity, target, pos);
    }

    public static boolean leave(Entity entity) {
        if (!(entity.level() instanceof ServerLevel from)) {
            return false;
        }
        ServerLevel overworld = from.getServer().overworld();
        Vec3 pos = Vec3.atBottomCenterOf(overworld.getSharedSpawnPos());
        return teleport(entity, overworld, pos);
    }

    private static boolean teleport(Entity entity, ServerLevel target, Vec3 pos) {
        DimensionTransition transition = new DimensionTransition(
                target, pos, Vec3.ZERO, entity.getYRot(), entity.getXRot(), DimensionTransition.DO_NOTHING);
        return entity.changeDimension(transition) != null;
    }
}
