package dev.chronoshift;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class TimeStopWatchItem extends Item {
    public static final int DURATION_TICKS = 20 * 10;
    public static final int COOLDOWN_TICKS = 20 * 60;

    public TimeStopWatchItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (TimeStop.isActive()) {
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel serverLevel) {
            TimeStop.start(serverLevel.getServer(), player.getUUID(), DURATION_TICKS);
            player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 0.5F);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
