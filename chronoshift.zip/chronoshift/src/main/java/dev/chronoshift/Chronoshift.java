package dev.chronoshift;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(Chronoshift.MOD_ID)
public class Chronoshift {
    public static final String MOD_ID = "chronoshift";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final DeferredItem<Item> TIME_CRYSTAL = ITEMS.registerSimpleItem("time_crystal");
    public static final DeferredItem<TimeStopWatchItem> TIME_STOP_WATCH =
            ITEMS.registerItem("time_stop_watch", TimeStopWatchItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MOD_ID))
                    .icon(() -> TIME_STOP_WATCH.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(TIME_CRYSTAL.get());
                        output.accept(TIME_STOP_WATCH.get());
                    })
                    .build());

    public Chronoshift(IEventBus modBus) {
        ITEMS.register(modBus);
        TABS.register(modBus);
    }
}
